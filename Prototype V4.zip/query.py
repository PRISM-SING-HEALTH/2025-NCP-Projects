import streamlit as st
import pandas as pd

def query(df):
    """
    Queries dataframe based on user input. Has case insensitive comparison.

    Args:
        df (pd.DataFrame): Input dataframe.

    Returns:
        query_result (pd.DataFrame): Query result.
    """
    # User selects a category
    category = st.selectbox("Select a category", df.columns)

    # User inputs the item to query
    item = st.text_input(f"Enter item to search in category '{category}'")

    # Ensure the button is always visible
    if st.button("🔍 Query"):
        if not item:
            st.warning("Please enter an item to search.")
        else:
            with st.spinner("Searching..."):
                # Perform the query with case-insensitive comparison
                query_result = df[df[category].astype(str).str.contains(item, case=False, na=False)]

                # Display query results
                if query_result.empty:
                    st.warning(f"No results found for item containing '{item}' in category '{category}'.")
                else:
                    st.success(f"{len(query_result)} record(s) found.")
                    st.write(query_result)

                    # Export button to download the queried data
                    csv = query_result.to_csv(index=False)
                    st.download_button(
                        label="⬇️ Download Queried Data (CSV)",
                        data=csv,
                        file_name="queried_data.csv",
                        mime="text/csv",
                    )
        
        return query_result